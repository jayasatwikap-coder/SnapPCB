# Architecture
Camera → preprocessing → Snapdragon-optimized AI → detection/OCR → reference comparison → diagnosis → dashboard/report.
