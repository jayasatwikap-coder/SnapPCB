# Models
Document model architecture, dataset, class list, export format, Qualcomm AI Hub optimization result and inference benchmark. Avoid committing large model binaries unless appropriate.
