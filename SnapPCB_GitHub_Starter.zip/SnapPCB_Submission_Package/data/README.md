# Dataset
Use only data you are permitted to publish.

Suggested classes:
- resistor
- capacitor
- led
- diode
- transistor
- ic
- connector
- relay
- missing_component
- misplaced_component
- visual_solder_defect

Document annotation format and train/validation/test split.
