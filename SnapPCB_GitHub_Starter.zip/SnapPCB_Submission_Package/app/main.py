def main():
    print("SnapPCB prototype scaffold")
    print("Connect the camera, trained detector, OCR, reference comparison and dashboard here.")

if __name__ == "__main__":
    main()
